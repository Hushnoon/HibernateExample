package domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "DBO.FACULTY_DTLS")
public class Faculty {

    @Id
    private String fclty_cd;
    private String src_icd;
    private String name;
    private String password;

    public String getFclty_cd() {
        return fclty_cd;
    }

    public void setFclty_cd(String fclty_cd) {
        this.fclty_cd = fclty_cd;
    }

    public String getSrc_icd() {
        return src_icd;
    }

    public void setSrc_icd(String src_icd) {
        this.src_icd = src_icd;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

}
